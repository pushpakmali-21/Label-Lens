import React, { useState } from "react";
import { ShieldCheck, LockKeyhole, UserPlus } from "lucide-react";
import { API, useAuth } from "../context/AuthContext";

const initial = { username_or_email: "", password: "", username: "", email: "", full_name: "" };

export default function Login({ onLogin }) {
  const { login } = useAuth();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState(initial);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const update = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  async function submit(e) {
    e.preventDefault(); setError(""); setLoading(true);
    try {
      const path = mode === "login" ? "/auth/login" : "/auth/register";
      const body = mode === "login"
        ? { username_or_email: form.username_or_email, password: form.password }
        : { username: form.username, email: form.email, password: form.password, full_name: form.full_name };
      const res = await fetch(API + path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || "Request failed");
      if (mode === "register") {
        setMode("login");
        setForm((f) => ({ ...initial, username_or_email: f.username }));
        return;
      }
      login(data);
      onLogin?.(data.user);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  return <div className="min-h-[75vh] flex items-center justify-center py-10">
    <div className="w-full max-w-md bg-panel border border-panel-line rounded-2xl p-6 sm:p-8 shadow-glass">
      <div className="flex items-center gap-3 mb-6"><div className="p-3 rounded-xl bg-brass/10 text-brass"><ShieldCheck size={28}/></div><div><h1 className="text-xl font-bold">LabelLens Access</h1><p className="text-xs text-text-2">Secure compliance platform</p></div></div>
      <div className="flex bg-panel-darker p-1 rounded-lg mb-6"><button type="button" className={`flex-1 py-2 rounded-md text-sm ${mode === "login" ? "bg-brass text-white" : "text-text-2"}`} onClick={()=>setMode("login")}>Sign in</button><button type="button" className={`flex-1 py-2 rounded-md text-sm ${mode === "register" ? "bg-brass text-white" : "text-text-2"}`} onClick={()=>setMode("register")}>Create account</button></div>
      <form onSubmit={submit} className="space-y-4">
        {mode === "register" && <>
          <label className="block text-xs text-text-2">Full name<input name="full_name" value={form.full_name} onChange={update} className="mt-1 w-full rounded-lg border border-panel-line bg-white p-2.5" required /></label>
          <label className="block text-xs text-text-2">Username<input name="username" value={form.username} onChange={update} className="mt-1 w-full rounded-lg border border-panel-line bg-white p-2.5" required /></label>
          <label className="block text-xs text-text-2">Email<input name="email" type="email" value={form.email} onChange={update} className="mt-1 w-full rounded-lg border border-panel-line bg-white p-2.5" required /></label>
          <div className="text-xs text-text-3 bg-panel-darker rounded-lg p-3">New self-registered accounts start as <strong>VIEWER</strong>. An administrator grants privileged roles.</div>
        </>}
        {mode === "login" && <label className="block text-xs text-text-2">Username or email<input name="username_or_email" value={form.username_or_email} onChange={update} className="mt-1 w-full rounded-lg border border-panel-line bg-white p-2.5" required /></label>}
        <label className="block text-xs text-text-2">Password<input name="password" type="password" value={form.password} onChange={update} className="mt-1 w-full rounded-lg border border-panel-line bg-white p-2.5" required minLength={8}/></label>
        {error && <div className="text-sm text-status-fail bg-status-fail/10 border border-status-fail/20 rounded-lg p-3">{error}</div>}
        <button disabled={loading} className="w-full flex items-center justify-center gap-2 bg-brass text-white rounded-lg py-2.5 font-semibold disabled:opacity-60">{mode === "login" ? <LockKeyhole size={16}/> : <UserPlus size={16}/>} {loading ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
      </form>
    </div>
  </div>;
}
