# LabelLens — Engineer 4 Platform Features

## Added
- JWT authentication with bcrypt password hashing and role-based authorization.
- User roles: ADMIN, INSPECTOR, OFFICER, VIEWER.
- Public registration safely creates VIEWER accounts; ADMIN-only account creation supports privileged roles.
- `backend/create_admin.py` bootstrap utility for the first administrator.
- Notices CRUD APIs and frontend management UI with create/edit/status/delete controls.
- Read-only district summary and live audit feed APIs over the existing Audit/Violation tables.
- Platform dashboard with district compliance visualization and auto-refreshing live feed.
- Background ecommerce URL checking with SSRF-safe validation, timeout/retry controls, job status, deterministic QR parsing and the existing LMPC validator interface.
- React authentication context, login/logout/session hydration, role-aware navigation, dashboard, notices and ecommerce screens.
- Alembic migration for Engineer 4 user/notice/ecommerce tables.
- Engineer 4 unit/security regression tests.
- `RUN_ENGINEER4.md` local setup and run instructions.

## Compatibility boundaries
- Existing vision, scan response, LMPC validator and evidence sealing code were not modified.
- Existing scan and audit routers remain registered.
- Dashboard district values are read from existing audit payloads; when no district is present, `Unknown` is used instead of changing the Audit schema.

## Verification
- Python source compilation passes in the available environment.
- Full backend integration tests require the Python dependencies and a running PostgreSQL instance.
- Frontend build requires installing the Node dependencies in the target environment (`npm.cmd install`).
- No real secrets are committed.
