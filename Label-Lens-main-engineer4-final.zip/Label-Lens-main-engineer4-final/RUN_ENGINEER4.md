# LabelLens — Engineer 4 Run Guide

## Project root
Open the folder containing `package.json` and `backend/` in VS Code. The ZIP supplied for this version is flattened so `package.json` is at the project root.

## 1. Frontend
Open a terminal in the project root:

```powershell
npm.cmd install
npm.cmd run dev
```

Open `http://localhost:5173`.

Optional frontend environment file: create `.env` in the project root with:

```env
VITE_API_URL=http://localhost:8000/api/v1
```

## 2. PostgreSQL + Redis
Docker is the easiest local setup. From `backend/`:

```powershell
docker compose up -d db redis
```

## 3. Backend environment
Copy `backend/.env.example` to `backend/.env`.

For local Windows development, the default database URL is already configured for the Docker PostgreSQL container:

```env
DATABASE_URL=postgresql+asyncpg://labellens:labellens_dev@localhost:5432/labellens
```

Change `SECRET_KEY` to a strong random value outside local demos.

## 4. Python environment
From `backend/`:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks activation, use a new Command Prompt and run `.venv\Scripts\activate.bat`.

## 5. Database migrations

```powershell
alembic upgrade head
```

## 6. Create the first administrator

```powershell
python create_admin.py
```

Public signup always creates a `VIEWER`. Use the bootstrap script or an existing ADMIN account to create privileged users.

## 7. Start FastAPI

```powershell
uvicorn app.main:app --reload
```

API docs: `http://127.0.0.1:8000/docs`

Health: `http://127.0.0.1:8000/health`

## Engineer 4 APIs

- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/logout`
- `POST /api/v1/auth/users` (ADMIN only)
- `POST/GET/PUT/DELETE /api/v1/notices...`
- `GET /api/v1/dashboard/district-summary`
- `GET /api/v1/dashboard/live-feed`
- `POST /api/v1/ecommerce/check`
- `GET /api/v1/ecommerce/check/{job_id}`

The dashboard and live feed consume existing audit/violation records. Vision, scan response, LMPC rules, and evidence sealing remain outside Engineer 4's implementation.
