from datetime import datetime
from uuid import UUID
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field
from app.models.enums import NoticePriority, NoticeStatus

class NoticeCreate(BaseModel):
    title: str = Field(min_length=3, max_length=255)
    description: str = Field(min_length=3)
    district: Optional[str] = Field(default=None, max_length=120)
    priority: NoticePriority = NoticePriority.MEDIUM
    status: NoticeStatus = NoticeStatus.ACTIVE

class NoticeUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=3, max_length=255)
    description: Optional[str] = Field(default=None, min_length=3)
    district: Optional[str] = Field(default=None, max_length=120)
    priority: Optional[NoticePriority] = None
    status: Optional[NoticeStatus] = None

class NoticeResponse(BaseModel):
    id: UUID
    title: str
    description: str
    district: Optional[str]
    priority: NoticePriority
    status: NoticeStatus
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)
