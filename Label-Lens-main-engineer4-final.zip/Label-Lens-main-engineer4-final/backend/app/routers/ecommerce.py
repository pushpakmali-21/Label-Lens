from uuid import UUID
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import AsyncSessionLocal, get_db
from app.core.deps import get_current_user
from app.models.ecommerce import EcommerceJob
from app.models.enums import EcommerceJobStatus
from app.models.user import User
from app.schemas.ecommerce import EcommerceCheckRequest, EcommerceJobResponse
from app.services.ecommerce_checker import inspect_product_page

router=APIRouter(prefix="/ecommerce", tags=["Ecommerce"])

async def run_job(job_id: UUID):
    async with AsyncSessionLocal() as db:
        job=(await db.execute(select(EcommerceJob).where(EcommerceJob.id==job_id))).scalar_one_or_none()
        if not job: return
        job.status=EcommerceJobStatus.RUNNING.value; await db.commit()
        try:
            result=await inspect_product_page(job.url)
            job.status=EcommerceJobStatus.COMPLETED.value; job.result_json=result; job.error=None
        except Exception as exc:
            job.status=EcommerceJobStatus.FAILED.value; job.error=str(exc)[:1000]
        await db.commit()

@router.post("/check", response_model=EcommerceJobResponse, status_code=202)
async def create_check(payload:EcommerceCheckRequest, background_tasks:BackgroundTasks, db:AsyncSession=Depends(get_db), current_user:User=Depends(get_current_user)):
    job=EcommerceJob(url=str(payload.url),status=EcommerceJobStatus.QUEUED.value,created_by=current_user.id)
    db.add(job); await db.commit(); await db.refresh(job)
    background_tasks.add_task(run_job, job.id)
    return EcommerceJobResponse(job_id=job.id,status=job.status)

@router.get("/check/{job_id}", response_model=EcommerceJobResponse)
async def get_check(job_id:UUID, db:AsyncSession=Depends(get_db), _:User=Depends(get_current_user)):
    job=(await db.execute(select(EcommerceJob).where(EcommerceJob.id==job_id))).scalar_one_or_none()
    if not job: raise HTTPException(404,"Ecommerce job not found")
    return EcommerceJobResponse(job_id=job.id,status=job.status,result=job.result_json,error=job.error)
