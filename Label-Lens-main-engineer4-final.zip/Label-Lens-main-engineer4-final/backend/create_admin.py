"""Create the first LabelLens administrator.

Run from backend after configuring .env:
    python create_admin.py

This bootstrap utility is intentionally separate from public registration so a
new installation can create its first privileged account without exposing an
ADMIN role through the public signup API.
"""
import asyncio
import getpass
import sys

from sqlalchemy import select

from app.core.database import AsyncSessionLocal
from app.core.security import hash_password
from app.models.user import User


async def main() -> None:
    username = input("Admin username: ").strip()
    email = input("Admin email: ").strip()
    full_name = input("Full name: ").strip()
    password = getpass.getpass("Admin password (min 8 chars): ")
    if len(password) < 8:
        raise SystemExit("Password must be at least 8 characters.")

    async with AsyncSessionLocal() as db:
        existing = (await db.execute(
            select(User).where((User.username == username) | (User.email == email))
        )).scalar_one_or_none()
        if existing:
            raise SystemExit("A user with that username or email already exists.")
        db.add(User(
            username=username,
            email=email,
            full_name=full_name,
            role="ADMIN",
            hashed_password=hash_password(password),
        ))
        await db.commit()
    print("Administrator created successfully.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(130)
