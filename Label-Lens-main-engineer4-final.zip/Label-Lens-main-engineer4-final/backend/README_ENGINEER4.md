# Engineer 4 Platform Features

## Authentication
Set `SECRET_KEY` and optionally `ACCESS_TOKEN_EXPIRE_MINUTES` in `.env`. Register a user through `POST /api/v1/auth/register` and sign in through `POST /api/v1/auth/login`.

For a real deployment, disable public assignment of privileged roles and let an administrator provision `ADMIN`, `INSPECTOR`, and `OFFICER` accounts.

## Migration
Run the project's Alembic migrations against PostgreSQL:

```bash
cd backend
alembic upgrade head
```

The Engineer 4 migration creates `users`, `notices`, and `ecommerce_check_jobs`. If your team later adds a base revision, set this revision's `down_revision` to that base revision rather than creating a second migration chain.

## Platform endpoints
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/logout`
- `POST/GET/PUT/DELETE /api/v1/notices`
- `GET /api/v1/dashboard/district-summary`
- `GET /api/v1/dashboard/live-feed`
- `POST /api/v1/ecommerce/check`
- `GET /api/v1/ecommerce/check/{job_id}`

Dashboard endpoints consume existing `Audit` and `Violation` records. They do not change the vision, scan, LMPC, or evidence layers.
