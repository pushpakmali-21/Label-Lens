import uuid
from datetime import datetime
from sqlalchemy import Column, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base

class EcommerceJob(Base):
    __tablename__ = "ecommerce_check_jobs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    url = Column(String(2048), nullable=False)
    status = Column(String(32), nullable=False, default="queued", index=True)
    result_json = Column(JSONB, nullable=True)
    error = Column(Text, nullable=True)
    created_by = Column(UUID(as_uuid=True), nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
