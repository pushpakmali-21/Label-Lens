from collections import defaultdict
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.audit import Audit
from app.models.user import User
from app.services.district_lookup import district_from_audit
from app.schemas.dashboard import DistrictSummary, LiveFeedResponse, LiveFeedItem

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/district-summary", response_model=list[DistrictSummary])
async def district_summary(db: AsyncSession = Depends(get_db), _: User = Depends(get_current_user)):
    result = await db.execute(select(Audit).options(selectinload(Audit.violations)).order_by(Audit.created_at.desc()))
    audits = result.scalars().unique().all()
    stats = defaultdict(lambda: {"total": 0, "compliant": 0, "violations": 0})
    for audit in audits:
        district = district_from_audit(audit)
        stats[district]["total"] += 1
        count = len(audit.violations or [])
        stats[district]["violations"] += count
        if audit.verdict == "pass": stats[district]["compliant"] += 1
    return [DistrictSummary(district=d, total_scans=v["total"], compliant=v["compliant"], violations=v["violations"], violation_rate=round((v["violations"] / v["total"] * 100), 2) if v["total"] else 0) for d,v in sorted(stats.items())]

@router.get("/live-feed", response_model=LiveFeedResponse)
async def live_feed(limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0), db: AsyncSession = Depends(get_db), _: User = Depends(get_current_user)):
    result = await db.execute(select(Audit).options(selectinload(Audit.violations)).order_by(Audit.created_at.desc()).offset(offset).limit(limit))
    audits = result.scalars().unique().all()
    items=[]
    for a in audits:
        product=None
        if isinstance(a.result_json, dict):
            product=a.result_json.get("product_name") or a.result_json.get("product")
        severities=[v.severity for v in (a.violations or []) if v.severity]
        severity=max(severities, key=lambda x: {"critical":4,"high":3,"medium":2,"low":1}.get(x.lower(),0), default=None)
        items.append(LiveFeedItem(audit_id=a.id,timestamp=a.created_at,district=district_from_audit(a),status=a.verdict,violation_count=len(a.violations or []),product=product,severity=severity))
    return LiveFeedResponse(items=items,limit=limit,offset=offset)
