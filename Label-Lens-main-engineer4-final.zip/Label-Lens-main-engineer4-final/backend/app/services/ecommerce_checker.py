from urllib.parse import urlparse
import ipaddress, socket
import httpx
from bs4 import BeautifulSoup
from app.core.config import get_settings
from app.services.vision.qr_parser import parse_qr_payload
from app.utils.lmpc_validator import validate_package_data

def validate_safe_url(url: str) -> None:
    parsed=urlparse(url)
    if parsed.scheme not in {"http","https"} or not parsed.hostname:
        raise ValueError("Only http/https URLs are allowed")
    host=parsed.hostname.lower()
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise ValueError("Local URLs are not allowed")
    try:
        infos=socket.getaddrinfo(host, None)
        for info in infos:
            addr=ipaddress.ip_address(info[4][0])
            if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved or addr.is_multicast:
                raise ValueError("Private or local network targets are not allowed")
    except socket.gaierror as exc:
        raise ValueError("Hostname could not be resolved") from exc

async def inspect_product_page(url: str) -> dict:
    validate_safe_url(url)
    settings=get_settings()
    last_error=None
    for attempt in range(settings.ecommerce_max_retries + 1):
        try:
            async with httpx.AsyncClient(timeout=settings.ecommerce_request_timeout_seconds, follow_redirects=False, headers={"User-Agent":"LabelLens-ComplianceChecker/1.0"}) as client:
                response=await client.get(url)
            if 300 <= response.status_code < 400:
                raise ValueError("Redirects are disabled for SSRF safety")
            response.raise_for_status()
            content_type=response.headers.get("content-type", "")
            if "text/html" not in content_type:
                raise ValueError("URL did not return an HTML product page")
            soup=BeautifulSoup(response.text, "html.parser")
            for tag in soup(["script","style","noscript"]): tag.decompose()
            text=" ".join(soup.stripped_strings)
            title=soup.title.get_text(" ", strip=True) if soup.title else None

            # Reuse the existing deterministic extraction + LMPC validation interfaces.
            # This keeps ecommerce checking in the platform layer without changing the rule engine.
            extracted = {}
            parse_error = None
            try:
                extracted = parse_qr_payload(text)
            except ValueError as exc:
                parse_error = str(exc)
            fields, violations, verdict, verdict_note = validate_package_data(extracted, text)
            return {
                "url": url,
                "title": title,
                "status_code": response.status_code,
                "extracted_fields": extracted,
                "validation": {
                    "fields": fields,
                    "violations": violations,
                    "verdict": verdict,
                    "verdict_note": verdict_note,
                },
                "extraction_note": parse_error,
                "text_excerpt": text[:5000],
            }
        except Exception as exc:
            last_error=exc
            if attempt >= settings.ecommerce_max_retries: break
    raise ValueError(str(last_error) if last_error else "Ecommerce check failed")
