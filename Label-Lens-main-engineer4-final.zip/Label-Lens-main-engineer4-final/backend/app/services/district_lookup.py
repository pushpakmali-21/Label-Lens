from typing import Any

def district_from_audit(audit: Any) -> str:
    """Read a district when present in existing audit payloads; never alters Audit schema."""
    data = audit.result_json if isinstance(audit.result_json, dict) else {}
    for key in ("district", "District", "location_district"):
        if data.get(key): return str(data[key])
    location = data.get("location") if isinstance(data.get("location"), dict) else {}
    if location.get("district"): return str(location["district"])
    return "Unknown"
