from typing import Any, Optional
from uuid import UUID
from pydantic import BaseModel, Field, HttpUrl
from app.models.enums import EcommerceJobStatus

class EcommerceCheckRequest(BaseModel):
    url: HttpUrl

class EcommerceJobResponse(BaseModel):
    job_id: UUID
    status: EcommerceJobStatus
    result: Optional[dict[str, Any]] = None
    error: Optional[str] = None
