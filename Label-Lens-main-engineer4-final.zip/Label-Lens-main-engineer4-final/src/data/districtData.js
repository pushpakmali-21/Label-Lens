export const DISTRICT_METRICS = [
  {
    id: "delhi-central",
    name: "Central Delhi",
    state: "NCT of Delhi",
    totalAudited: 1420,
    compliant: 1192,
    violations: 228,
    complianceRate: 83.9,
    topViolation: "Font height below 2mm on SLAB_B snacks (Rule 7)",
    riskLevel: "medium",
    lat: 28.6139,
    lng: 77.2090,
  },
  {
    id: "mumbai-suburban",
    name: "Mumbai Suburban",
    state: "Maharashtra",
    totalAudited: 2180,
    compliant: 1656,
    violations: 524,
    complianceRate: 76.0,
    topViolation: "Prohibited expression 'net wt when packed' (Rule 11)",
    riskLevel: "high",
    lat: 19.0760,
    lng: 72.8777,
  },
  {
    id: "bengaluru-urban",
    name: "Bengaluru Urban",
    state: "Karnataka",
    totalAudited: 1890,
    compliant: 1682,
    violations: 208,
    complianceRate: 89.0,
    topViolation: "Missing country of origin filter on Q-Commerce apps (Rule 6(10A))",
    riskLevel: "low",
    lat: 12.9716,
    lng: 77.5946,
  },
  {
    id: "indore",
    name: "Indore",
    state: "Madhya Pradesh",
    totalAudited: 960,
    compliant: 748,
    violations: 212,
    complianceRate: 77.9,
    topViolation: "Missing mandatory telephone in consumer redressal block (Rule 6(1)(f))",
    riskLevel: "high",
    lat: 22.7196,
    lng: 75.8577,
  },
  {
    id: "kolkata",
    name: "Kolkata Metropolitan",
    state: "West Bengal",
    totalAudited: 1340,
    compliant: 1112,
    violations: 228,
    complianceRate: 83.0,
    topViolation: "Use of non-standard symbol 'gms' instead of 'g' (Rule 13)",
    riskLevel: "medium",
    lat: 22.5726,
    lng: 88.3639,
  },
  {
    id: "hyderabad",
    name: "Hyderabad",
    state: "Telangana",
    totalAudited: 1510,
    compliant: 1328,
    violations: 182,
    complianceRate: 87.9,
    topViolation: "Secondary face placement of Net Quantity (Rule 8)",
    riskLevel: "low",
    lat: 17.3850,
    lng: 78.4867,
  }
];

export let LIVE_AUDIT_FEED = [
  {
    id: "AUD-8921",
    timestamp: "2 mins ago",
    platform: "QuickCommerce App #1",
    product: "Organic Honey, 250 g",
    seller: "NaturePure Farms Ltd.",
    status: "violation",
    issue: "Non-standard unit 'gms' used; missing manufacturing date in listing",
    citation: "Rule 13 & Rule 6(10)",
    action: "Show-Cause Notice Queued"
  },
  {
    id: "AUD-8920",
    timestamp: "7 mins ago",
    platform: "Physical POS (Supermarket)",
    product: "Cashew Nuts, 500 g",
    seller: "Royal Agro Packs",
    status: "pass",
    issue: "Full compliance verified (font height 4.2mm >= 4.0mm threshold)",
    citation: "Rule 6(1) & Rule 7",
    action: "Digital Seal Granted"
  },
  {
    id: "AUD-8919",
    timestamp: "14 mins ago",
    platform: "E-Commerce Giant #2",
    product: "Wireless Earbuds with Mic",
    seller: "AudioTech India",
    status: "pass",
    issue: "Electronics QR proviso verified — address in decoded payload",
    citation: "Rule 6(1) Proviso (2022)",
    action: "Proviso Validated"
  },
  {
    id: "AUD-8918",
    timestamp: "21 mins ago",
    platform: "QuickCommerce App #3",
    product: "Atta Whole Wheat, 5 kg",
    seller: "Golden Harvest Mills",
    status: "violation",
    issue: "Prohibited statement 'Net weight when packed' detected in description",
    citation: "Rule 11(1)",
    action: "Notice Sent to Seller"
  }
];

export const getLiveAuditFeed = () => LIVE_AUDIT_FEED;

export const pushCitizenReport = (report) => {
  LIVE_AUDIT_FEED = [report, ...LIVE_AUDIT_FEED];
};
