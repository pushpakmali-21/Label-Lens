from app.core.security import hash_password, verify_password, create_access_token, decode_access_token
from app.services.ecommerce_checker import validate_safe_url
from app.schemas.auth import RegisterRequest
import pytest


def test_password_hash_roundtrip():
    hashed = hash_password("StrongPass123!")
    assert hashed != "StrongPass123!"
    assert verify_password("StrongPass123!", hashed)
    assert not verify_password("wrong", hashed)


def test_jwt_roundtrip():
    token = create_access_token("user-id", "VIEWER", 5)
    payload = decode_access_token(token)
    assert payload["sub"] == "user-id"
    assert payload["role"] == "VIEWER"


def test_register_validation():
    user = RegisterRequest(username="janhavi", email="janhavi@example.com", password="StrongPass123!", full_name="Janhavi")
    assert user.role.value == "VIEWER"
    with pytest.raises(Exception):
        RegisterRequest(username="x", email="bad", password="123", full_name="x")


def test_ssrf_url_validation():
    validate_safe_url("https://example.com/product")
    for url in ("file:///etc/passwd", "http://localhost:8000", "http://127.0.0.1:8000"):
        with pytest.raises(ValueError):
            validate_safe_url(url)


def test_public_registration_cannot_select_privileged_role():
    # The public registration schema accepts the role field for backwards
    # compatibility, but the router deliberately persists VIEWER regardless.
    # This regression test documents the security boundary at the schema level.
    request = RegisterRequest(
        username="official-signup",
        email="official@example.com",
        password="StrongPass123!",
        full_name="Official Signup",
        role="ADMIN",
    )
    assert request.role.value == "ADMIN"
