from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.models.notice import Notice
from app.models.user import User
from app.schemas.notice import NoticeCreate, NoticeResponse, NoticeUpdate

router = APIRouter(prefix="/notices", tags=["Notices"])

@router.post("", response_model=NoticeResponse, status_code=status.HTTP_201_CREATED)
async def create_notice(payload: NoticeCreate, db: AsyncSession = Depends(get_db), current_user: User = Depends(require_roles("ADMIN", "OFFICER"))):
    notice = Notice(**payload.model_dump(), priority=payload.priority.value, status=payload.status.value, created_by=current_user.id)
    db.add(notice)
    await db.commit(); await db.refresh(notice)
    return notice

@router.get("", response_model=list[NoticeResponse])
async def list_notices(limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0), db: AsyncSession = Depends(get_db), _: User = Depends(get_current_user)):
    result = await db.execute(select(Notice).order_by(Notice.created_at.desc()).offset(offset).limit(limit))
    return result.scalars().all()

@router.get("/{notice_id}", response_model=NoticeResponse)
async def get_notice(notice_id: UUID, db: AsyncSession = Depends(get_db), _: User = Depends(get_current_user)):
    notice = (await db.execute(select(Notice).where(Notice.id == notice_id))).scalar_one_or_none()
    if not notice: raise HTTPException(404, "Notice not found")
    return notice

@router.put("/{notice_id}", response_model=NoticeResponse)
async def update_notice(notice_id: UUID, payload: NoticeUpdate, db: AsyncSession = Depends(get_db), _: User = Depends(require_roles("ADMIN", "OFFICER"))):
    notice = (await db.execute(select(Notice).where(Notice.id == notice_id))).scalar_one_or_none()
    if not notice: raise HTTPException(404, "Notice not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(notice, key, value.value if hasattr(value, "value") else value)
    await db.commit(); await db.refresh(notice)
    return notice

@router.delete("/{notice_id}", status_code=204)
async def delete_notice(notice_id: UUID, db: AsyncSession = Depends(get_db), _: User = Depends(require_roles("ADMIN"))):
    notice = (await db.execute(select(Notice).where(Notice.id == notice_id))).scalar_one_or_none()
    if not notice: raise HTTPException(404, "Notice not found")
    await db.delete(notice); await db.commit()
