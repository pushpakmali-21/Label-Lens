from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel

class DistrictSummary(BaseModel):
    district: str
    total_scans: int
    compliant: int
    violations: int
    violation_rate: float

class LiveFeedItem(BaseModel):
    audit_id: UUID
    timestamp: datetime
    district: str
    status: str
    violation_count: int
    product: Optional[str] = None
    severity: Optional[str] = None

class LiveFeedResponse(BaseModel):
    items: list[LiveFeedItem]
    limit: int
    offset: int
