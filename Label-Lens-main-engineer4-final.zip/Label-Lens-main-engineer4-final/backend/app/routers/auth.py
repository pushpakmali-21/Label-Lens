from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import get_settings
from app.core.database import get_db
from app.core.deps import get_current_user, require_roles
from app.core.security import create_access_token, hash_password, verify_password
from app.models.user import User
from app.schemas.auth import AdminUserCreateRequest, LoginRequest, RegisterRequest, TokenResponse, UserResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = (await db.execute(select(User).where(or_(User.username == payload.username, User.email == payload.email)))).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Username or email already exists")
    # Public registration can never grant privileged roles. An ADMIN must create
    # INSPECTOR/OFFICER/ADMIN accounts through the protected endpoint below.
    user = User(username=payload.username, email=payload.email, full_name=payload.full_name,
                role="VIEWER", hashed_password=hash_password(payload.password))
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user

@router.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(payload: AdminUserCreateRequest, db: AsyncSession = Depends(get_db), _: User = Depends(require_roles("ADMIN"))):
    existing = (await db.execute(select(User).where(or_(User.username == payload.username, User.email == payload.email)))).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Username or email already exists")
    user = User(username=payload.username, email=payload.email, full_name=payload.full_name,
                role=payload.role.value, hashed_password=hash_password(payload.password))
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user

@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, db: AsyncSession = Depends(get_db)):
    user = (await db.execute(select(User).where(or_(User.username == payload.username_or_email, User.email == payload.username_or_email)))).scalar_one_or_none()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid username/email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="User account is inactive")
    token = create_access_token(str(user.id), user.role, get_settings().access_token_expire_minutes)
    return TokenResponse(access_token=token, user=user)

@router.get("/me", response_model=UserResponse)
async def me(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user)):
    # JWTs are stateless. Client-side token removal logs the user out.
    return {"message": "Logged out successfully"}
