from enum import Enum

class UserRole(str, Enum):
    ADMIN = "ADMIN"
    INSPECTOR = "INSPECTOR"
    OFFICER = "OFFICER"
    VIEWER = "VIEWER"

class NoticePriority(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class NoticeStatus(str, Enum):
    ACTIVE = "ACTIVE"
    RESOLVED = "RESOLVED"
    ARCHIVED = "ARCHIVED"

class EcommerceJobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
